#! /bin/bash
curtime=$(date +%s)
~/test/shellscript names2 .1
while (( $(ls|wc -l) <=4650 ))
do
~/test/fix.sh .7
sleep .5
done
endtime=$(date +%s)
(( timee=endtime-curtime ))
(( secs=timee%60 ))
(( timee/=60 ))
echo "It took "$timee" minutes "$secs
mail -s "$timee minutes" nacho0095@hotmail.com <allfiles.cleaned
mail nacho0095@hotmail.com <allfiles
