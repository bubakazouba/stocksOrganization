#! /bin/bash
while [[ ! -e allfiles.cleaned ]]
do
sleep 1
done
cut -d',' -f2 allfiles.cleaned >symbols
cat symbols ~/test/names2 > symballs
cat symballs |sort|uniq >names
cp names ~/test/names3
rm allfiles.cleaned
rm allfiles
rm symbols
rm symballs
rm names
~/test/shellscript names3 $1  

